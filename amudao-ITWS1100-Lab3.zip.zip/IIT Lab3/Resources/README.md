
READ ME FOR LAB 3

Title:Building a responsive website that will be updated with every lab/homework done in class

## Lab3
***
# Table of Contents
[1.General Info](#general-info)

[2.Working](#working)

[3.Styling](#styling)

[4.Links](#links)
***
## General Info
This project is based on creating an INDEX page with basic information of myself and a PROJECT page that includes all my previous and upcoming lab projects. It contains links to the lab projects file.
***

## Working
When we land on the website it directs us to the home page i.e INDEX page then using the menu bar we can navigate to the PROJECT page where there are several buttons linked to the lab projects.
By clicking on the buttons we are redirected to the particular lab project's webpage.
***

## Styling
To arrange and align the contents in a respective manner flexbox container has been used. Also used a background image so that the background looks cool.
***

## Links
[Home Page](index.html)

[Project Page](project.html)

[Styles](styles.css)
***

Background
When chooosing the background  decided to go for a simple blue because it was easy to see.

Images
I added an image of m because it made it more personal. If people are able to see me it would place a feeling of familiarity and make the story
I was crafting/telling more enjoyable. 

I also added pictures of my favourite anime 


Overall feeling of the lab

I had fun partaking in this lab. It was difficult but not that difficut that I wasn't able to do it.
 The most difficut part of this lab was styling and apperance. Making the website look the way I envisoned was difficult because css is weird.

This website isprobably my most impressive feat in college and it's something I'll hold dear to my heart.






URL: https://afsws.rpi.edu/AFS/home/76/amudao/public_html/
